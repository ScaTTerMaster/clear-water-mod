package com.example.clearwater.mixin;

import net.minecraft.class_127;
import net.minecraft.class_15;
import net.minecraft.class_18;
import net.minecraft.class_555;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_555.class)
public class GameRendererMixin {

    @Shadow
    private Minecraft minecraft;

    @Redirect(
        method = "renderFog",
        at = @At(value = "INVOKE",
            target = "Lnet/minecraft/entity/living/LivingEntity;isInFluid(Lnet/minecraft/block/material/Material;)Z",
            ordinal = 0)
    )
    private boolean clearWaterFogColor(class_127 entity, class_15 material) {
        return false;
    }

    @Redirect(
        method = "setupFog",
        at = @At(value = "INVOKE",
            target = "Lnet/minecraft/entity/living/LivingEntity;isInFluid(Lnet/minecraft/block/material/Material;)Z",
            ordinal = 0)
    )
    private boolean clearWaterFogDensity(class_127 entity, class_15 material) {
        return false;
    }

    @Redirect(
        method = "renderTick",
        at = @At(value = "INVOKE",
            target = "Lnet/minecraft/level/Level;getBrightness(III)F")
    )
    private float limitUnderwaterDarkness(class_18 level, int x, int y, int z) {
        float brightness = level.method_1782(x, y, z);
        class_127 entity = this.minecraft.field_2807;
        if (entity != null && entity.method_1328(class_15.field_985)) {
            return Math.max(brightness, 0.4f);
        }
        return brightness;
    }
}
