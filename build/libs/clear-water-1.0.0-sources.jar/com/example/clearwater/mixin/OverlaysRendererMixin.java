package com.example.clearwater.mixin;

import net.minecraft.class_15;
import net.minecraft.class_40;
import net.minecraft.class_556;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_556.class)
public class OverlaysRendererMixin {

    @Redirect(
        method = "renderOverlays",
        at = @At(value = "INVOKE",
            target = "Lnet/minecraft/entity/living/player/AbstractClientPlayer;isInFluid(Lnet/minecraft/block/material/Material;)Z")
    )
    private boolean clearWaterOverlay(class_40 player, class_15 material) {
        return false;
    }
}
